package com.example.timetracker;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(16,21,29), CARD = Color.rgb(27,35,46);
    private final int TEXT = Color.rgb(240,244,248), MUTED = Color.rgb(157,170,185);
    private final int GREEN = Color.rgb(99,214,165), RED = Color.rgb(242,112,112);
    private EditText nameInput, startInput, endInput;
    private LinearLayout recordsBox;
    private TextView resultText, saveButton;
    private SharedPreferences prefs;
    private JSONArray records = new JSONArray();
    private int editing = -1;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("time_tracker", MODE_PRIVATE);
        loadRecords();
        buildScreen();
        renderRecords();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.RIGHT); return t;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w,h); }
    private void pad(View v, int a) { v.setPadding(a,a,a,a); }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        LinearLayout root = vertical(); root.setPadding(20,22,20,28); scroll.addView(root);
        TextView title = text("⏱  Time Tracker", 26, TEXT, true); title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-1,-2));
        TextView sub = text("سجّل كل مهمة واحسب مدتها بشكل مستقل", 14, MUTED, false);
        sub.setGravity(Gravity.CENTER); LinearLayout.LayoutParams sp=lp(-1,-2); sp.topMargin=8; sp.bottomMargin=22; root.addView(sub,sp);

        LinearLayout form = vertical(); form.setPadding(16,18,16,18); form.setBackground(shape(CARD,22));
        root.addView(form, lp(-1,-2));
        TextView formTitle=text("إضافة تسجيل جديد",19,TEXT,true); form.addView(formTitle);
        form.addView(label("اسم التسجيل"));
        nameInput=field("مثلاً: العمل الأول"); form.addView(nameInput,lp(-1,52));
        form.addView(label("وقت البداية"));
        startInput=field("اضغط لاختيار وقت البداية"); startInput.setFocusable(false); form.addView(startInput,lp(-1,52));
        form.addView(label("وقت النهاية"));
        endInput=field("اضغط لاختيار وقت النهاية"); endInput.setFocusable(false); form.addView(endInput,lp(-1,52));
        startInput.setOnClickListener(v -> chooseTime(startInput));
        endInput.setOnClickListener(v -> chooseTime(endInput));
        resultText=text("سيظهر فارق الوقت هنا",15,GREEN,true); resultText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rp=lp(-1,-2); rp.topMargin=14; rp.bottomMargin=10; form.addView(resultText,rp);
        TextView save=text("حفظ التسجيل",16,BG,true); save.setGravity(Gravity.CENTER);
        save.setBackground(shape(GREEN,16)); pad(save,15); form.addView(save,lp(-1,-2));
        save.setOnClickListener(v -> saveRecord());

        TextView listTitle=text("التسجيلات المحفوظة",20,TEXT,true);
        LinearLayout.LayoutParams tp=lp(-1,-2); tp.topMargin=25; tp.bottomMargin=12; root.addView(listTitle,tp);
        recordsBox=vertical(); root.addView(recordsBox,lp(-1,-2));
        setContentView(scroll);
    }
    private TextView label(String s) {
        TextView t=text(s,14,MUTED,true); LinearLayout.LayoutParams p=lp(-1,-2);
        p.topMargin=13; p.bottomMargin=6; t.setLayoutParams(p); return t;
    }
    private EditText field(String hint) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setTextColor(TEXT);
        e.setHintTextColor(MUTED); e.setHint(hint); e.setTextSize(15);
        e.setPadding(14,0,14,0); e.setBackground(shape(Color.rgb(37,47,61),14));
        e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); return e;
    }
    private void chooseTime(EditText target) {
        int h=8,m=0;
        String current=target.getText().toString();
        try { String[] p=current.split(":"); h=Integer.parseInt(p[0]); m=Integer.parseInt(p[1]); } catch(Exception ignored) {}
        new TimePickerDialog(this,(view, hour, minute) ->
                target.setText(String.format(Locale.US,"%02d:%02d",hour,minute)),h,m,true).show();
    }
    private int minutes(String s) {
        String[] p=s.split(":");
        if(p.length!=2) throw new IllegalArgumentException();
        int h=Integer.parseInt(p[0]), m=Integer.parseInt(p[1]);
        if(h<0||h>23||m<0||m>59) throw new IllegalArgumentException();
        return h*60+m;
    }
    private String duration(String a, String b) {
        int diff=(minutes(b)-minutes(a)+1440)%1440;
        return (diff/60>0 ? (diff/60)+" ساعة و " : "")+(diff%60)+" دقيقة";
    }
    private void saveRecord() {
        String name=nameInput.getText().toString().trim();
        String start=startInput.getText().toString().trim(), end=endInput.getText().toString().trim();
        if(name.isEmpty()||start.isEmpty()||end.isEmpty()) {
            Toast.makeText(this,"أدخل الاسم ووقت البداية والنهاية",Toast.LENGTH_SHORT).show(); return;
        }
        try {
            String dur=duration(start,end);
            JSONObject item=new JSONObject(); item.put("name",name); item.put("start",start);
            item.put("end",end); item.put("duration",dur);
            if(editing>=0) records.put(editing,item); else records.put(item);
            editing=-1; persist(); clearForm(); renderRecords();
            Toast.makeText(this,"تم حفظ التسجيل",Toast.LENGTH_SHORT).show();
        } catch(Exception ex) {
            Toast.makeText(this,"تحقق من الوقت المدخل",Toast.LENGTH_SHORT).show();
        }
    }
    private void clearForm() {
        nameInput.setText(""); startInput.setText(""); endInput.setText("");
        resultText.setText("سيظهر فارق الوقت هنا");
    }
    private void persist() { prefs.edit().putString("records",records.toString()).apply(); }
    private void loadRecords() {
        try { records=new JSONArray(prefs.getString("records","[]")); }
        catch(Exception e) { records=new JSONArray(); }
    }
    private void renderRecords() {
        recordsBox.removeAllViews();
        if(records.length()==0) {
            TextView empty=text("لا توجد تسجيلات بعد. أضف أول تسجيل من الأعلى.",14,MUTED,false);
            empty.setGravity(Gravity.CENTER); empty.setPadding(10,25,10,25); recordsBox.addView(empty); return;
        }
        for(int i=records.length()-1;i>=0;i--) {
            final int index=i;
            try {
                JSONObject o=records.getJSONObject(i);
                LinearLayout card=vertical(); card.setPadding(16,14,16,14);
                card.setBackground(shape(CARD,18));
                LinearLayout.LayoutParams cp=lp(-1,-2); cp.bottomMargin=10; recordsBox.addView(card,cp);
                TextView n=text(o.optString("name"),18,TEXT,true); card.addView(n);
                TextView times=text("البداية: "+o.optString("start")+"     النهاية: "+o.optString("end"),14,MUTED,false);
                LinearLayout.LayoutParams t=lp(-1,-2); t.topMargin=8; card.addView(times,t);
                TextView d=text("الفارق: "+o.optString("duration"),16,GREEN,true);
                LinearLayout.LayoutParams dp=lp(-1,-2); dp.topMargin=8; card.addView(d,dp);
                LinearLayout actions=horizontal(); LinearLayout.LayoutParams ap=lp(-1,-2); ap.topMargin=10; card.addView(actions,ap);
                TextView edit=text("تعديل",14,GREEN,true); edit.setGravity(Gravity.CENTER);
                edit.setPadding(18,9,18,9); edit.setBackground(shape(Color.rgb(39,75,66),12));
                actions.addView(edit,lp(0,-2)); ((LinearLayout.LayoutParams)edit.getLayoutParams()).weight=1;
                TextView del=text("حذف",14,RED,true); del.setGravity(Gravity.CENTER);
                del.setPadding(18,9,18,9); del.setBackground(shape(Color.rgb(75,43,49),12));
                LinearLayout.LayoutParams dl=lp(0,-2); dl.weight=1; dl.leftMargin=8; actions.addView(del,dl);
                edit.setOnClickListener(v -> editRecord(index));
                del.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
                    .setMessage("هل تريد حذف هذا التسجيل؟")
                    .setNegativeButton("إلغاء",null)
                    .setPositiveButton("حذف",(dialog,which)->{records.remove(index);persist();renderRecords();})
                    .show());
            } catch(Exception ignored) {}
        }
    }
    private void editRecord(int i) {
        try {
            JSONObject o=records.getJSONObject(i);
            nameInput.setText(o.optString("name")); startInput.setText(o.optString("start"));
            endInput.setText(o.optString("end")); editing=i;
            resultText.setText("المدة: "+o.optString("duration"));
            Toast.makeText(this,"عدّل البيانات ثم اضغط حفظ التسجيل",Toast.LENGTH_LONG).show();
        } catch(Exception ignored) {}
    }
}